class Count:
    def __init__(self):
        self.count = 0

    def count_up(self):
        self.count += 1
        print(self.count)

